function whatsapp(){
				window.location="https://wa.me/message/URWTIJL3O4BCL1"
				
				}
				function instagram(){
				window.location="https://instagram.com/p.e.t_1?igshid=bizoo8gmoj2m"
				
				}
function google(){
				window.location="https://g.page/pranav-s-production-house?gm"
				
				}
function tele(){
				window.location="tel:+918657387331"
				
				}
function email(){
				window.location="mailto: pranav24rajeevan@gmail.com"
				
				}
function youtube(){
				window.location="https://m.youtube.com/channel/UCEn4JEZZSE0Bmjyu5sQFtRw"
				
				}
